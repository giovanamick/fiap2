package br.com.fiap.catalogo.model.entity;

import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Table(name = "jogos")
@Entity(name = "Jogo")
public class Jogo {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String titulo;
	private String desenvolvedora;
	private String idiomas;
	private String numeroDeJogadores;
	private String dataDeLancamento;

	@Enumerated(EnumType.STRING)
	private Genero genero;

	@Embedded
	private RequisitosDeSistema requisitosDeSistema;
	private Boolean ativo;

	public Jogo() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getDesenvolvedora() {
		return desenvolvedora;
	}

	public void setDesenvolvedora(String desenvolvedora) {
		this.desenvolvedora = desenvolvedora;
	}

	public String getIdiomas() {
		return idiomas;
	}

	public void setIdiomas(String idiomas) {
		this.idiomas = idiomas;
	}

	public String getNumeroDeJogadores() {
		return numeroDeJogadores;
	}

	public void setNumeroDeJogadores(String numeroDeJogadores) {
		this.numeroDeJogadores = numeroDeJogadores;
	}

	public String getDataDeLancamento() {
		return dataDeLancamento;
	}

	public void setDataDeLancamento(String dataDeLancamento) {
		this.dataDeLancamento = dataDeLancamento;
	}

	public Genero getGenero() {
		return genero;
	}

	public void setGenero(Genero genero) {
		this.genero = genero;
	}

	public RequisitosDeSistema getRequisitosDeSistema() {
		return requisitosDeSistema;
	}

	public void setRequisitosDeSistema(RequisitosDeSistema requisitosDeSistema) {
		this.requisitosDeSistema = requisitosDeSistema;
	}

	public Boolean getAtivo() {
		return ativo;
	}

	public void setAtivo(Boolean ativo) {
		this.ativo = ativo;
	}

}
