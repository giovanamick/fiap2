package br.com.fiap.catalogo.model.entity;

public enum Genero {
	ACAO,
	TIRO,
	RPG,
	CORRIDA,
	ESPORTE,
	SIMULADOR
}
