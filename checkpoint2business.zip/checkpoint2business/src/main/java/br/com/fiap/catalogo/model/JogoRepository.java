package br.com.fiap.catalogo.model;

import org.springframework.data.jpa.repository.JpaRepository;
import br.com.fiap.catalogo.model.entity.Jogo;

public interface JogoRepository extends JpaRepository<Jogo, Long> {
	
}