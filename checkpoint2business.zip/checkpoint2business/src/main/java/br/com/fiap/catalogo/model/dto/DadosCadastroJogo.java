package br.com.fiap.catalogo.model.dto;

import br.com.fiap.catalogo.model.entity.Genero;

public record DadosCadastroJogo(
		String titulo,
		String desenvolvedora,
		String distribuidora,
		String idiomas,
		String numeroDeJogadores,
		String dataDeLancamento,
		Genero genero,
		DadosRequisitosDeSistema requisitosDeSistema
	) {
	
	public void Jogo(DadosCadastroJogo dados) {
		this.ativo = true;
		this.titulo = dados.titulo();
		this.desenvolvedora = dados.desenvolvedora();
		this.distribuidora = dados.distribuidora();
		this.idiomas = dados.idiomas();
		this.numeroDeJogadores = dados.numeroDeJogadores();
		this.dataDeLancamento = dados.dataDeLancamento();
		this.genero = dados.genero();
		this.requisitosDeSistema = dados.requisitosDeSistema();
	}
	
}
