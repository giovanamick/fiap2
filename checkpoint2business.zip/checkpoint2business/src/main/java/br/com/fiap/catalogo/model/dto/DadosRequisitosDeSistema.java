package br.com.fiap.catalogo.model.dto;

public record DadosRequisitosDeSistema(
		String sistemaOperacional,
		String processador,
		String memoria,
		String placaDeVideo,
		String armazenamento
	) {
	
	public RequisitosDeSistema(DadosRequisitosDeSistema requisitosDeSistema) {
		this.sistemaOperacional = requisitosDeSistema.sistemaOperacional();
		this.processador = requisitosDeSistema.processador();
		this.memoria = requisitosDeSistema.memoria();
		this.placaDeVideo = requisitosDeSistema.placaDeVideo();
	}
}
