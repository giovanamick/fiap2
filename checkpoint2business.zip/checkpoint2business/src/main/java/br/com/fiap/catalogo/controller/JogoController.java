package br.com.fiap.catalogo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.fiap.catalogo.model.JogoRepository;
import br.com.fiap.catalogo.model.dto.DadosCadastroJogo;
import br.com.fiap.catalogo.model.entity.Jogo;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/jogos")
public class JogoController {
	
	@Autowired
	private JogoRepository repository;
	
	@PostMapping
	@Transactional
	public void cadastrar(@RequestBody @Valid DadosCadastroJogo dados) {
		repository.save(new Jogo(dados));
		
	}

}
