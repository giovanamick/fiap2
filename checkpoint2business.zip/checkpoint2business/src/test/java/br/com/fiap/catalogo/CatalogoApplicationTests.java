package br.com.fiap.catalogo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatalogoApplicationTests {

	@Test
	void contextLoads() {
	}

}
